# app/screens/lighting.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QGroupBox
)
from PyQt5.QtCore import Qt, QTimer
import random  # to simulate ambient light

class LightingScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("💡 Automatic Artificial Lighting Control")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Crop selection
        crop_group = QGroupBox("Select Crop Under Artificial Lighting")
        crop_layout = QVBoxLayout()
        self.crop_select = QComboBox()
        self.crop_select.addItems(["Onion", "Carrot"])
        crop_layout.addWidget(self.crop_select)
        crop_group.setLayout(crop_layout)
        layout.addWidget(crop_group)

        # Status label
        self.status_label = QLabel("Lights status will update automatically")
        self.status_label.setStyleSheet("font-size:14px; font-weight:500;")
        layout.addWidget(self.status_label)

        # Intensity label
        self.intensity_label = QLabel("Light Intensity: 0%")
        self.intensity_label.setStyleSheet("font-size:14px; font-weight:500;")
        layout.addWidget(self.intensity_label)

        self.setLayout(layout)

        # Start auto-update timer (simulate real-time ambient light every 2 seconds)
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_control)
        self.timer.start(4000)  # update every 2 seconds

    def auto_control(self):
        """Automatic ON/OFF and intensity adjustment based on simulated ambient light"""
        ambient_light = random.randint(20, 100)  # simulate ambient light percentage

        # Logic: if ambient light < 60% turn ON lights
        if ambient_light < 60:
            intensity = min(100, 100 - ambient_light)  # brightness to reach 100%
            self.status_label.setText(
                f"Lights ON for {self.crop_select.currentText()} | Ambient light: {ambient_light}%"
            )
            self.intensity_label.setText(f"Artificial Light Intensity: {intensity}%")
        else:
            self.status_label.setText(
                f"Lights OFF for {self.crop_select.currentText()} | Ambient light: {ambient_light}%"
            )
            self.intensity_label.setText("Artificial Light Intensity: 0%")
