# app/screens/pest_detection.py
import random
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog
)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


class PestDetectionScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🐛 Pest & Disease Detection")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Image display
        self.image_label = QLabel("No image uploaded")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("border: 1px solid gray; min-height:200px;")
        layout.addWidget(self.image_label)

        # Upload button
        self.upload_btn = QPushButton("Upload Crop Leaf Image")
        self.upload_btn.clicked.connect(self.upload_image)
        layout.addWidget(self.upload_btn)

        # Result label
        self.result_label = QLabel("")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setStyleSheet("font-size:14px; font-weight:500;")
        layout.addWidget(self.result_label)

        self.setLayout(layout)

    def upload_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Crop Leaf Image", "", "Image Files (*.png *.jpg *.jpeg)"
        )
        if not file_path:
            return

        # Display image
        pixmap = QPixmap(file_path)
        pixmap = pixmap.scaled(300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.image_label.setPixmap(pixmap)

        # Dummy analysis
        result = random.choice(["Healthy", "Pest Detected"])
        if result == "Healthy":
            advice = "✅ Crop looks healthy. Continue regular care."
        else:
            advice = "⚠️ Pest detected! Apply appropriate pesticide or organic treatment."

        self.result_label.setText(f"Result: {result}\n{advice}")
