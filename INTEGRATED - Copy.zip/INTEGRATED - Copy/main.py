# master_launcher/main.py
import sys
import subprocess
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget,
    QLabel, QLineEdit, QMessageBox, QStackedWidget, QFrame
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont


class LoginScreen(QWidget):
    def __init__(self, switch_to_launcher):
        super().__init__()
        self.switch_to_launcher = switch_to_launcher

        # Semi-transparent login panel
        panel = QFrame()
        panel.setStyleSheet("""
            QFrame {
                background-color: rgba(0, 0, 0, 150);
                border-radius: 15px;
            }
        """)
        panel_layout = QVBoxLayout(panel)
        panel_layout.setSpacing(15)
        panel_layout.setContentsMargins(40, 40, 40, 40)
        panel_layout.setAlignment(Qt.AlignCenter)

        title = QLabel("🌱 Smart Farm Login")
        title.setFont(QFont("Arial", 18, QFont.Bold))
        title.setStyleSheet("color: white;")
        panel_layout.addWidget(title, alignment=Qt.AlignCenter)

        self.username = QLineEdit()
        self.username.setPlaceholderText("Enter Username")
        self.username.setStyleSheet("padding:10px; border-radius:10px;")
        panel_layout.addWidget(self.username)

        self.password = QLineEdit()
        self.password.setPlaceholderText("Enter Password")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setStyleSheet("padding:10px; border-radius:10px;")
        panel_layout.addWidget(self.password)

        login_btn = QPushButton("Login")
        login_btn.setStyleSheet(self.button_style())
        login_btn.clicked.connect(self.check_login)
        panel_layout.addWidget(login_btn)

        # Main layout with background
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.addWidget(panel, alignment=Qt.AlignCenter)

        self.set_background()

    def set_background(self):
        """Set background image"""
        self.setStyleSheet("""
            QWidget {
                background-image: url("bg_image.jpg");
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
            }
        """)

    def check_login(self):
        """Simple hardcoded login (extendable later)"""
        if self.username.text() == "admin" and self.password.text() == "1234":
            self.switch_to_launcher()
        else:
            QMessageBox.warning(self, "Login Failed", "Invalid Username or Password")

    def button_style(self):
        return """
        QPushButton {
            background-color: #28a745;
            color: white;
            border-radius: 12px;
            padding: 10px 20px;
            font-size: 14px;
        }
        QPushButton:hover {
            background-color: #218838;
        }
        """


class Launcher(QWidget):
    def __init__(self):
        super().__init__()

        # Semi-transparent panel for buttons
        panel = QFrame()
        panel.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 200);
                border-radius: 20px;
            }
        """)
        layout = QVBoxLayout(panel)
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)

        title = QLabel("🚀 Smart Agricultural Master Launcher")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: black;")
        layout.addWidget(title, alignment=Qt.AlignCenter)

        # Project Buttons
        self.add_button(layout, "Basic Smart Farm", "project1/main.py", "#24df5c")
        self.add_button(layout, "Artificial Lighting", "project2/main.py", "#ffc107")
        self.add_button(layout, "Aquaponics + Multi-Storey", "project3/main.py", "#80580c")
        self.add_button(layout, "Full Integrated Smart Farm", "project4/main.py", "#6f42c1")

        main_layout = QVBoxLayout(self)
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(panel, alignment=Qt.AlignCenter)

        self.set_background()

    def set_background(self):
        """Set background image"""
        self.setStyleSheet("""
            QWidget {
                background-image: url("background_launcher.jpg");
                background-repeat: no-repeat;
                background-position: center;
                background-size: cover;
            }
        """)

    def add_button(self, layout, text, path, color):
        btn = QPushButton(text)
        btn.setStyleSheet(self.button_style(color))
        btn.clicked.connect(lambda: self.launch_project(path))
        layout.addWidget(btn)

    def launch_project(self, path):
        subprocess.Popen([sys.executable, path])

    def button_style(self, color):
        return f"""
        QPushButton {{
            background-color: {color};
            color: white;
            border-radius: 15px;
            padding: 12px;
            font-size: 14px;
            font-weight: bold;
        }}
        QPushButton:hover {{
            background-color: #000000;
        }}
        """


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🌱 Smart Agricultural System")
        self.setGeometry(300, 200, 600, 400)

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.login_screen = LoginScreen(self.show_launcher)
        self.launcher = Launcher()

        self.stack.addWidget(self.login_screen)
        self.stack.addWidget(self.launcher)

    def show_launcher(self):
        self.stack.setCurrentWidget(self.launcher)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
