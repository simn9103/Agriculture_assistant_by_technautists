# data/sensor_data.py
import random

class SensorData:
    def __init__(self):
        # Generate fake sensor data
        self.moisture = random.randint(20, 80)      # Soil moisture %
        self.ph = round(random.uniform(5.5, 7.5), 2) # Soil pH
        self.temp = random.randint(18, 35)          # °C
        self.minerals = random.randint(40, 100)     # ppm

    def get_data(self):
        """Return sensor values as dictionary"""
        return {
            "moisture": self.moisture,
            "ph": self.ph,
            "temperature": self.temp,
            "minerals": self.minerals
        }
