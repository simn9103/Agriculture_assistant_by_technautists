import requests

API_KEY = "7ae6ae4090ab287f5d6e5af2518c5708"  # Replace this with your actual key, no quotes extra
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def get_weather(city: str):
    """Fetch current weather data for a city from OpenWeatherMap."""
    if not API_KEY or API_KEY == "7ae6ae4090ab287f5d6e5af2518c5708":
        return {"error": "API key is missing or not set."}

    params = {"q": city, "appid": API_KEY, "units": "metric"}
    try:
        response = requests.get(BASE_URL, params=params, timeout=10)
        data = response.json()

        if response.status_code != 200:
            return {"error": f"{data.get('message', 'API request failed.')} (HTTP {response.status_code})"}

        weather_info = {
            "city": data["name"],
            "temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "description": data["weather"][0]["description"].capitalize(),
            "wind": data["wind"]["speed"]
        }
        return weather_info
    except requests.exceptions.RequestException as e:
        return {"error": f"Network error: {e}"}
