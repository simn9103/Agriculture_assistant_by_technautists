# app/screens/dashboard.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QHBoxLayout,
    QSpinBox, QDoubleSpinBox, QPushButton, QGroupBox, QComboBox
)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt


class DashboardScreen(QWidget):
    def __init__(self):
        super().__init__()

        # Crop requirements (ideal ranges)
        self.crop_requirements = {
            "Rice": {
                "moisture": (60, 80),
                "ph": (5.5, 6.5),
                "temp": (20, 35),
                "minerals": (70, 150)
            },
            "Wheat": {
                "moisture": (40, 60),
                "ph": (6.0, 7.5),
                "temp": (15, 25),
                "minerals": (50, 120)
            }
        }

        # Default sensor values
        self.values = {
            "moisture": 50,
            "ph": 6.5,
            "temp": 25,
            "minerals": 100
        }

        # Main layout
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop)

        # Title
        title = QLabel("🌾 Real-Time Farm Dashboard — Crop-Specific Analysis")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        main_layout.addWidget(title)

        # Crop selection
        crop_group = QGroupBox("Select Crop")
        crop_layout = QHBoxLayout()
        self.crop_select = QComboBox()
        self.crop_select.addItems(self.crop_requirements.keys())
        crop_layout.addWidget(QLabel("Crop:"))
        crop_layout.addWidget(self.crop_select)
        crop_group.setLayout(crop_layout)
        main_layout.addWidget(crop_group)

        # Sensor input panel
        input_group = QGroupBox("Manual Sensor Inputs (Demo)")
        input_layout = QHBoxLayout()

        # Moisture input
        self.moisture_input = QSpinBox()
        self.moisture_input.setRange(0, 100)
        self.moisture_input.setValue(self.values["moisture"])
        input_layout.addWidget(QLabel("Moisture (%)"))
        input_layout.addWidget(self.moisture_input)

        # pH input
        self.ph_input = QDoubleSpinBox()
        self.ph_input.setRange(0.0, 14.0)
        self.ph_input.setSingleStep(0.1)
        self.ph_input.setDecimals(2)
        self.ph_input.setValue(self.values["ph"])
        input_layout.addWidget(QLabel("pH"))
        input_layout.addWidget(self.ph_input)

        # Temp input
        self.temp_input = QSpinBox()
        self.temp_input.setRange(-10, 60)
        self.temp_input.setValue(self.values["temp"])
        input_layout.addWidget(QLabel("Temp (°C)"))
        input_layout.addWidget(self.temp_input)

        # Minerals input
        self.minerals_input = QSpinBox()
        self.minerals_input.setRange(0, 1000)
        self.minerals_input.setValue(self.values["minerals"])
        input_layout.addWidget(QLabel("Minerals (ppm)"))
        input_layout.addWidget(self.minerals_input)

        # Apply button
        self.apply_btn = QPushButton("Apply & Analyze")
        self.apply_btn.clicked.connect(self.apply_inputs)
        input_layout.addWidget(self.apply_btn)

        input_group.setLayout(input_layout)
        main_layout.addWidget(input_group)

        # Current values display
        self.status_label = QLabel("Select crop and apply inputs to see analysis.")
        self.status_label.setStyleSheet("font-size:14px; font-weight:500;")
        main_layout.addWidget(self.status_label)

        # Matplotlib chart
        fig, self.ax = plt.subplots(figsize=(6, 3.2))
        self.canvas = FigureCanvas(fig)
        main_layout.addWidget(self.canvas)

        self.setLayout(main_layout)

        # Initial draw
        self.draw_chart()

    def apply_inputs(self):
        """Update values, compare with crop requirements, update chart and status."""
        self.values["moisture"] = self.moisture_input.value()
        self.values["ph"] = self.ph_input.value()
        self.values["temp"] = self.temp_input.value()
        self.values["minerals"] = self.minerals_input.value()

        crop = self.crop_select.currentText()
        reqs = self.crop_requirements[crop]

        analysis = [f"🌱 Crop Selected: {crop}\n"]

        # Compare each sensor value with crop requirements
        for key, (low, high) in reqs.items():
            val = self.values[key]
            if low <= val <= high:
                analysis.append(f"✅ {key.capitalize()} ({val}) is optimal.")
            else:
                analysis.append(f"⚠️ {key.capitalize()} ({val}) is out of range ({low}-{high}).")

        self.status_label.setText("\n".join(analysis))
        self.draw_chart()

    def draw_chart(self):
        """Draw a bar chart comparing current vs ideal ranges."""
        self.ax.clear()
        crop = self.crop_select.currentText()
        reqs = self.crop_requirements[crop]

        labels = ["Moisture", "pH", "Temp", "Minerals"]
        values = [
            self.values["moisture"],
            self.values["ph"] * 10,   # scaled for visibility
            self.values["temp"],
            self.values["minerals"]
        ]
        ideal_low = [reqs["moisture"][0], reqs["ph"][0] * 10, reqs["temp"][0], reqs["minerals"][0]]
        ideal_high = [reqs["moisture"][1], reqs["ph"][1] * 10, reqs["temp"][1], reqs["minerals"][1]]

        # Bars for actual values
        bars = self.ax.bar(labels, values, color="skyblue", label="Current")

        # Draw ideal ranges as horizontal lines
        for i, (low, high) in enumerate(zip(ideal_low, ideal_high)):
            self.ax.plot([i - 0.3, i + 0.3], [low, low], color="green", linestyle="--")
            self.ax.plot([i - 0.3, i + 0.3], [high, high], color="red", linestyle="--")

        self.ax.set_title(f"Sensor Data vs Ideal Range ({crop})")
        self.ax.legend()
        self.canvas.draw_idle()
