# app/screens/irrigation.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QSpinBox,
    QPushButton, QTextEdit, QGroupBox, QHBoxLayout
)
from PyQt5.QtCore import Qt


class IrrigationScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("💧 Irrigation Scheduler")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Crop selection
        crop_group = QGroupBox("Select Crop")
        crop_layout = QHBoxLayout()
        self.crop_select = QComboBox()
        self.crop_select.addItems(["Rice", "Wheat"])
        crop_layout.addWidget(QLabel("Crop:"))
        crop_layout.addWidget(self.crop_select)
        crop_group.setLayout(crop_layout)
        layout.addWidget(crop_group)

        # Soil moisture input
        moisture_group = QGroupBox("Soil Moisture (%)")
        moisture_layout = QHBoxLayout()
        self.moisture_input = QSpinBox()
        self.moisture_input.setRange(0, 100)
        self.moisture_input.setValue(50)
        moisture_layout.addWidget(QLabel("Current Moisture:"))
        moisture_layout.addWidget(self.moisture_input)
        moisture_group.setLayout(moisture_layout)
        layout.addWidget(moisture_group)

        # Weather selection
        weather_group = QGroupBox("Weather Condition")
        weather_layout = QHBoxLayout()
        self.weather_select = QComboBox()
        self.weather_select.addItems(["Sunny", "Cloudy", "Rainy"])
        weather_layout.addWidget(QLabel("Today:"))
        weather_layout.addWidget(self.weather_select)
        weather_group.setLayout(weather_layout)
        layout.addWidget(weather_group)

        # Schedule button
        self.schedule_btn = QPushButton("Generate Irrigation Schedule")
        self.schedule_btn.clicked.connect(self.generate_schedule)
        layout.addWidget(self.schedule_btn)

        # Result display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        self.result_box.setStyleSheet("font-size:13px;")
        layout.addWidget(self.result_box)

        self.setLayout(layout)

    def generate_schedule(self):
        """Generate irrigation schedule based on crop, soil moisture, and weather."""
        crop = self.crop_select.currentText()
        moisture = self.moisture_input.value()
        weather = self.weather_select.currentText()

        schedule = f"🌱 Crop: {crop}\n🌡️ Soil Moisture: {moisture}%\n☀️ Weather: {weather}\n\n"

        # Simple rules for demo
        if crop == "Rice":
            base_interval = 2  # days
            base_water = 5000  # liters per hectare
        else:  # Wheat
            base_interval = 3
            base_water = 3000

        # Adjust for moisture
        if moisture < 30:
            interval = max(1, base_interval - 1)
            schedule += "💧 Soil is dry — shorten irrigation interval.\n"
        elif moisture > 70:
            interval = base_interval + 1
            schedule += "💧 Soil is wet — delay next irrigation.\n"
        else:
            interval = base_interval
            schedule += "💧 Soil moisture is optimal.\n"

        # Adjust for weather
        if weather == "Rainy":
            interval += 1
            schedule += "🌧️ Rain expected — postpone irrigation.\n"

        schedule += f"📅 Recommended irrigation every {interval} day(s)\n"
        schedule += f"💦 Water quantity: {base_water} liters per hectare"

        self.result_box.setText(schedule)
