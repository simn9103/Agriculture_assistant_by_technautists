# app/screens/pest_detection.py
import os
import numpy as np
try:
    import cv2
    OPENCV_AVAILABLE = True
except Exception:
    OPENCV_AVAILABLE = False

import random
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog, QHBoxLayout,
    QSlider, QGroupBox, QFormLayout, QSpinBox
)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt


class PestDetectionScreen(QWidget):
    """
    Simple heuristic-based pest/disease detector using OpenCV.
    - Calculates proportion of 'green' vs 'non-green', 'brown', and 'dark' pixels.
    - Combines them into a diseased_score and compares to a user-adjustable threshold.
    """

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🐛 Pest & Disease Detection")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Image area
        self.image_label = QLabel("No image uploaded")
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet(
            "border: 1px solid gray; min-height:200px; background-color:#f7f7f7;"
        )
        layout.addWidget(self.image_label)

        # Buttons
        btn_layout = QHBoxLayout()
        self.upload_btn = QPushButton("Upload Crop Leaf Image")
        self.upload_btn.clicked.connect(self.upload_image)
        btn_layout.addWidget(self.upload_btn)

        self.reset_btn = QPushButton("Reset")
        self.reset_btn.clicked.connect(self.reset_screen)
        btn_layout.addWidget(self.reset_btn)

        layout.addLayout(btn_layout)

        # Sensitivity / threshold controls
        sens_group = QGroupBox("Detection Sensitivity")
        sens_layout = QFormLayout()
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setRange(1, 50)   # percent threshold (1% - 50%)
        self.threshold_slider.setValue(15)     # default 15%
        self.threshold_slider.setTickInterval(1)
        self.threshold_slider.setTickPosition(QSlider.TicksBelow)
        self.threshold_slider.valueChanged.connect(self.on_threshold_change)

        self.threshold_label = QLabel("Threshold: 15% diseased-score")
        sens_layout.addRow(self.threshold_label, self.threshold_slider)
        sens_group.setLayout(sens_layout)
        layout.addWidget(sens_group)

        # Debug / metrics display
        metrics_group = QGroupBox("Analysis Metrics")
        metrics_layout = QVBoxLayout()
        self.metrics_label = QLabel("No analysis yet.")
        self.metrics_label.setWordWrap(True)
        metrics_layout.addWidget(self.metrics_label)
        metrics_group.setLayout(metrics_layout)
        layout.addWidget(metrics_group)

        # Result label
        self.result_label = QLabel("")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setStyleSheet("font-size:14px; font-weight:500; padding:5px;")
        layout.addWidget(self.result_label)

        self.setLayout(layout)

        # Internal
        self.current_image_path = None

    def on_threshold_change(self):
        val = self.threshold_slider.value()
        self.threshold_label.setText(f"Threshold: {val}% diseased-score")
        # If an image is loaded, re-run analysis with new threshold
        if self.current_image_path:
            self.run_analysis(self.current_image_path)

    def upload_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Crop Leaf Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp)"
        )
        if not file_path:
            return

        # keep path
        self.current_image_path = file_path

        # Display the image
        pixmap = QPixmap(file_path)
        pixmap = pixmap.scaled(400, 400, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.image_label.setPixmap(pixmap)
        self.image_label.setText("")  # remove default text

        # If OpenCV is available use heuristic analysis, else fallback to improved random
        if OPENCV_AVAILABLE:
            self.run_analysis(file_path)
        else:
            # graceful fallback
            self.result_label.setText("⚠️ OpenCV not available — using fallback random check.")
            self.fallback_random()

    def fallback_random(self):
        # Slightly weighted random to favor healthy
        pest_chance = random.randint(0, 100)
        if pest_chance < 80:
            result = "Healthy"
            advice = "✅ Crop looks healthy (fallback result)."
        else:
            result = "Pest Detected"
            advice = "⚠️ Pest detected (fallback result)."
        self.result_label.setText(f"Result: {result}\n{advice}")
        self.metrics_label.setText("No image analysis (OpenCV not installed).")

    def reset_screen(self):
        """Reset image and results"""
        self.current_image_path = None
        self.image_label.clear()
        self.image_label.setText("No image uploaded")
        self.result_label.clear()
        self.metrics_label.setText("No analysis yet.")
        self.threshold_slider.setValue(15)

    def run_analysis(self, file_path):
        """Run OpenCV heuristic analysis and update UI."""
        try:
            img = cv2.imread(file_path)
            if img is None:
                raise ValueError("Could not read image file.")

            # Resize for consistent processing
            img_proc = cv2.resize(img, (400, 400), interpolation=cv2.INTER_AREA)
            hsv = cv2.cvtColor(img_proc, cv2.COLOR_BGR2HSV)
            h = hsv[:, :, 0]
            s = hsv[:, :, 1]
            v = hsv[:, :, 2]

            # Heuristic masks (tweakable)
            # green mask: typical green hue roughly 35-85 (in OpenCV H range 0-179)
            green_mask = ((h >= 35) & (h <= 85) & (s >= 50) & (v >= 40))
            green_ratio = float(np.count_nonzero(green_mask)) / green_mask.size

            # brown-ish mask: hue ~5-25 with medium-high saturation/value (brown/lesion)
            brown_mask = ((h >= 5) & (h <= 25) & (s >= 40) & (v >= 30))
            brown_ratio = float(np.count_nonzero(brown_mask)) / brown_mask.size

            # dark spots: low brightness
            dark_mask = (v < 50)
            dark_ratio = float(np.count_nonzero(dark_mask)) / dark_mask.size

            non_green_ratio = 1.0 - green_ratio

            # Combine into a single diseased score (weights chosen empirically for demo)
            diseased_score = (non_green_ratio * 0.6) + (brown_ratio * 0.3) + (dark_ratio * 0.1)
            diseased_pct = diseased_score * 100.0

            # Threshold from slider (user-controlled)
            threshold_pct = float(self.threshold_slider.value())

            # Confidence (rough)
            confidence = min(99, int(diseased_pct * 2))  # scaled to 0-99 for display

            # Decide
            if diseased_pct >= threshold_pct:
                label = "Pest Detected"
                advice = "⚠️ Pest/disease symptoms detected — inspect & treat. (Heuristic)"
            else:
                label = "Healthy"
                advice = "✅ Leaf appears healthy (Heuristic)."

            # Update UI metrics and result
            metrics = (
                f"Green: {green_ratio*100:.1f}% | Non-green: {non_green_ratio*100:.1f}%\n"
                f"Brown-like: {brown_ratio*100:.1f}% | Dark pixels: {dark_ratio*100:.1f}%\n"
                f"Diseased-score: {diseased_pct:.1f}% | Threshold: {threshold_pct}%\n"
                f"Confidence (approx): {confidence}%"
            )
            self.metrics_label.setText(metrics)
            self.result_label.setText(f"Result: {label}\n{advice}")

        except Exception as e:
            # if anything goes wrong, fallback gracefully
            self.result_label.setText(f"❌ Analysis failed: {e}\nUsing fallback random.")
            self.fallback_random()
