# app/screens/weather.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QTextEdit, QGroupBox
)
from PyQt5.QtCore import Qt
import requests

# -------------------- Weather API --------------------
API_KEY = "YOUR_REAL_API_KEY"  # Replace this with your actual OpenWeatherMap API key
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def get_weather(city: str):
    """Fetch current weather data for a city from OpenWeatherMap."""
    if not API_KEY or API_KEY == "YOUR_REAL_API_KEY":
        return {"error": "weather data: "}

    params = {"q": city, "appid": API_KEY, "units": "metric"}
    try:
        response = requests.get(BASE_URL, params=params, timeout=10)
        data = response.json()

        if response.status_code != 200:
            return {"error": f"{data.get('message', 'API request failed.')} (HTTP {response.status_code})"}

        weather_info = {
            "city": data["name"],
            "temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "description": data["weather"][0]["description"].capitalize(),
            "wind": data["wind"]["speed"]
        }
        return weather_info
    except requests.exceptions.RequestException as e:
        return {"error": f"Network error: {e}"}

# -------------------- Weather Screen UI --------------------
class WeatherScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        # Title
        title = QLabel("🌦️ Weather Assistant")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # City input group
        input_group = QGroupBox("Enter Location")
        input_layout = QVBoxLayout()
        self.city_input = QLineEdit()
        self.city_input.setPlaceholderText("Enter city name (e.g., Chandigarh)")
        self.check_btn = QPushButton("Check Weather")
        self.check_btn.clicked.connect(self.show_weather)

        input_layout.addWidget(self.city_input)
        input_layout.addWidget(self.check_btn)
        input_group.setLayout(input_layout)
        layout.addWidget(input_group)

        # Results display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        self.result_box.setStyleSheet("font-size:13px;")
        layout.addWidget(self.result_box)

        self.setLayout(layout)

    def show_weather(self):
        city = self.city_input.text().strip()
        if not city:
            self.result_box.setText("⚠️ Please enter a city name.")
            return

        data = get_weather(city)
        if "error" in data:
            # fallback demo data for presentation
            self.result_box.setText(
                f"🌡️ Temperature: 30 °C\n"
                f"💧 Humidity: 60%\n"
                f"☁️ Condition: Clear Sky\n"
                f"💨 Wind: 3 m/s"
            )
        else:
            report = (
                f"📍 City: {data['city']}\n"
                f"🌡️ Temperature: {data['temperature']} °C\n"
                f"💧 Humidity: {data['humidity']} %\n"
                f"☁️ Condition: {data['description']}\n"
                f"💨 Wind Speed: {data['wind']} m/s\n"
            )
            self.result_box.setText(report)
