# app/screens/alerts.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QGroupBox, QComboBox, QSpinBox, QDoubleSpinBox
)
from PyQt5.QtCore import Qt


class AlertsScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🔔 Automated Alerts & Recommendations")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Crop selection
        crop_group = QGroupBox("Select Crop")
        crop_layout = QVBoxLayout()
        self.crop_select = QComboBox()
        self.crop_select.addItems(["Rice", "Wheat"])
        crop_layout.addWidget(self.crop_select)
        crop_group.setLayout(crop_layout)
        layout.addWidget(crop_group)

        # Sensor inputs
        sensor_group = QGroupBox("Enter Sensor Values (Demo)")
        sensor_layout = QVBoxLayout()
        self.moisture_input = QSpinBox()
        self.moisture_input.setRange(0, 100)
        self.moisture_input.setValue(50)
        sensor_layout.addWidget(QLabel("Soil Moisture (%)"))
        sensor_layout.addWidget(self.moisture_input)

        self.ph_input = QDoubleSpinBox()
        self.ph_input.setRange(0.0, 14.0)
        self.ph_input.setDecimals(2)
        self.ph_input.setSingleStep(0.1)
        self.ph_input.setValue(6.5)
        sensor_layout.addWidget(QLabel("Soil pH"))
        sensor_layout.addWidget(self.ph_input)

        self.temp_input = QSpinBox()
        self.temp_input.setRange(-10, 60)
        self.temp_input.setValue(25)
        sensor_layout.addWidget(QLabel("Temperature (°C)"))
        sensor_layout.addWidget(self.temp_input)

        self.minerals_input = QSpinBox()
        self.minerals_input.setRange(0, 1000)
        self.minerals_input.setValue(80)
        sensor_layout.addWidget(QLabel("Mineral Content (ppm)"))
        sensor_layout.addWidget(self.minerals_input)

        sensor_group.setLayout(sensor_layout)
        layout.addWidget(sensor_group)

        # Weather input
        weather_group = QGroupBox("Weather (Demo)")
        weather_layout = QVBoxLayout()
        self.weather_select = QComboBox()
        self.weather_select.addItems(["Sunny", "Cloudy", "Rainy"])
        weather_layout.addWidget(QLabel("Current Weather:"))
        weather_layout.addWidget(self.weather_select)
        weather_group.setLayout(weather_layout)
        layout.addWidget(weather_group)

        # Generate Alerts button
        self.alert_btn = QPushButton("Generate Alerts")
        self.alert_btn.clicked.connect(self.generate_alerts)
        layout.addWidget(self.alert_btn)

        # Alerts display
        self.alert_box = QTextEdit()
        self.alert_box.setReadOnly(True)
        self.alert_box.setStyleSheet("font-size:13px;")
        layout.addWidget(self.alert_box)

        self.setLayout(layout)

    def generate_alerts(self):
        """Generate alerts based on crop, sensors, and weather."""
        crop = self.crop_select.currentText()
        moisture = self.moisture_input.value()
        ph = self.ph_input.value()
        temp = self.temp_input.value()
        minerals = self.minerals_input.value()
        weather = self.weather_select.currentText()

        alerts = []

        # Crop-specific ideal ranges (simplified)
        crop_ranges = {
            "Rice": {"moisture": (60, 80), "ph": (5.5, 6.5), "temp": (20, 35), "minerals": (70, 150)},
            "Wheat": {"moisture": (40, 60), "ph": (6.0, 7.5), "temp": (15, 25), "minerals": (50, 120)}
        }
        ranges = crop_ranges[crop]

        # Soil moisture alerts
        if moisture < ranges["moisture"][0]:
            alerts.append("💧 Soil moisture is low — irrigate immediately.")
        elif moisture > ranges["moisture"][1]:
            alerts.append("⚠️ Soil moisture is high — delay irrigation.")

        # pH alerts
        if ph < ranges["ph"][0]:
            alerts.append("🧪 Soil is acidic — apply lime.")
        elif ph > ranges["ph"][1]:
            alerts.append("🧪 Soil is alkaline — consider sulfur or organic matter.")

        # Temperature alerts
        if temp < ranges["temp"][0]:
            alerts.append("🌡️ Temperature is low — crop growth may slow.")
        elif temp > ranges["temp"][1]:
            alerts.append("🌡️ Temperature is high — consider mulching.")

        # Mineral alerts
        if minerals < ranges["minerals"][0]:
            alerts.append("🌾 Minerals are low — apply NPK fertilizer.")
        elif minerals > ranges["minerals"][1]:
            alerts.append("⚠️ Minerals are high — monitor for salinity.")

        # Weather alerts
        if weather == "Rainy":
            alerts.append("🌧️ Rain expected — check irrigation schedule.")
        elif weather == "Sunny":
            alerts.append("☀️ Sunny day — irrigation may be required soon.")

        # If no alerts
        if not alerts:
            alerts.append("✅ All parameters are within optimal ranges.")

        # Display alerts
        self.alert_box.setText("\n".join(alerts))
