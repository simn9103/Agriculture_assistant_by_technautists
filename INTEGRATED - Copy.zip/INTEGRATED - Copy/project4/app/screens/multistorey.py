# app/screens/multistorey.py
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QGroupBox
from PyQt5.QtCore import Qt
import random

class MultiStoreyScreen(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🏢 Multi-Storey Farm Analytics")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Upper story analytics
        upper_group = QGroupBox("🌞 Upper Story - Long Day Crops")
        upper_layout = QVBoxLayout()
        self.upper_box = QTextEdit()
        self.upper_box.setReadOnly(True)
        upper_layout.addWidget(self.upper_box)
        upper_group.setLayout(upper_layout)
        layout.addWidget(upper_group)

        # Lower story analytics
        lower_group = QGroupBox("🌤️ Lower Story - Short Day Crops")
        lower_layout = QVBoxLayout()
        self.lower_box = QTextEdit()
        self.lower_box.setReadOnly(True)
        lower_layout.addWidget(self.lower_box)
        lower_group.setLayout(lower_layout)
        layout.addWidget(lower_group)

        self.setLayout(layout)

        # Generate demo analytics
        self.generate_analytics()

    def generate_analytics(self):
        # Simulated data for demo
        upper_info = (
            f"Crop: Sunflower\n"
            f"Growth Stage: {random.choice(['Vegetative', 'Flowering'])}\n"
            f"Sunlight Required: 10-12 hrs/day\n"
            f"Soil Moisture: {random.randint(40, 60)}%\n"
            f"CO₂ Injected: {random.randint(5, 15)} m³\n"
            f"Water Injected: {random.randint(50, 150)} liters\n"
        )
        self.upper_box.setText(upper_info)

        lower_info = (
            f"Crop: Radish\n"
            f"Growth Stage: {random.choice(['Vegetative', 'Flowering'])}\n"
            f"Sunlight Required: 6-8 hrs/day\n"
            f"Soil Moisture: {random.randint(30, 50)}%\n"
            f"CO₂ Injected: {random.randint(3, 10)} m³\n"
            f"Water Injected: {random.randint(30, 100)} liters\n"
        )
        self.lower_box.setText(lower_info)
