# app/screens/aquaponics.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QSpinBox, QDoubleSpinBox,
    QPushButton, QTextEdit, QComboBox, QGroupBox
)
from PyQt5.QtCore import Qt, QTimer
import random  # for demo sensor simulation

class AquaponicsScreen(QWidget):
    def __init__(self, soil_screen=None, dashboard_callback=None):
        """
        soil_screen: instance of SoilAnalysisScreen for current soil conditions
        dashboard_callback: optional function to log water injection
        """
        super().__init__()

        self.soil_screen = soil_screen
        self.dashboard_callback = dashboard_callback
        self.total_water_injected = 0

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🐟 Aquaponics Water Management")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Crop selection
        crop_group = QGroupBox("Select Crop")
        crop_layout = QVBoxLayout()
        self.crop_select = QComboBox()
        self.crop_select.addItems(["Rice", "Wheat"])
        crop_layout.addWidget(self.crop_select)
        crop_group.setLayout(crop_layout)
        layout.addWidget(crop_group)

        # Growth stage selection
        stage_group = QGroupBox("Growth Stage")
        stage_layout = QVBoxLayout()
        self.stage_select = QComboBox()
        self.stage_select.addItems(["Vegetative", "Flowering"])
        stage_layout.addWidget(self.stage_select)
        stage_group.setLayout(stage_layout)
        layout.addWidget(stage_group)

        # Available water input
        water_group = QGroupBox("Available Water (liters)")
        water_layout = QVBoxLayout()
        self.water_input = QSpinBox()
        self.water_input.setRange(100, 10000)
        self.water_input.setValue(500)
        water_layout.addWidget(QLabel("Water available:"))
        water_layout.addWidget(self.water_input)
        water_group.setLayout(water_layout)
        layout.addWidget(water_group)

        # Sensor simulation for minerals
        mineral_group = QGroupBox("Water Mineral Levels (ppm)")
        mineral_layout = QVBoxLayout()
        self.nitrate_input = QSpinBox()
        self.nitrate_input.setRange(0, 100)
        self.nitrate_input.setValue(20)
        self.phosphate_input = QSpinBox()
        self.phosphate_input.setRange(0, 50)
        self.phosphate_input.setValue(10)
        self.potassium_input = QSpinBox()
        self.potassium_input.setRange(0, 50)
        self.potassium_input.setValue(15)
        mineral_layout.addWidget(QLabel("Nitrate:"))
        mineral_layout.addWidget(self.nitrate_input)
        mineral_layout.addWidget(QLabel("Phosphate:"))
        mineral_layout.addWidget(self.phosphate_input)
        mineral_layout.addWidget(QLabel("Potassium:"))
        mineral_layout.addWidget(self.potassium_input)
        mineral_group.setLayout(mineral_layout)
        layout.addWidget(mineral_group)

        # Result display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        layout.addWidget(self.result_box)

        self.setLayout(layout)

        # Timer for automatic water injection check
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_inject_water)
        self.timer.start(3000)  # every 3 seconds

    def auto_inject_water(self):
        crop = self.crop_select.currentText()
        stage = self.stage_select.currentText()
        water_available = self.water_input.value()

        # Sensor data
        nitrate = self.nitrate_input.value()
        phosphate = self.phosphate_input.value()
        potassium = self.potassium_input.value()

        # Crop-specific thresholds
        thresholds = {
            "Rice": {
                "Vegetative": {"nitrate":10, "phosphate":5, "potassium":15},
                "Flowering": {"nitrate":20, "phosphate":10, "potassium":20}
            },
            "Wheat": {
                "Vegetative": {"nitrate":8, "phosphate":4, "potassium":12},
                "Flowering": {"nitrate":15, "phosphate":8, "potassium":18}
            }
        }

        crop_thresh = thresholds[crop][stage]

        # Check if minerals sufficient
        sufficient = (nitrate >= crop_thresh["nitrate"] and
                      phosphate >= crop_thresh["phosphate"] and
                      potassium >= crop_thresh["potassium"])

        if sufficient:
            water_injected = min(100, water_available)  # inject up to 100 liters per cycle
            self.total_water_injected += water_injected
            self.result_box.setText(
                f"💧 Water injected to {crop} ({stage}) crops: {water_injected} liters\n"
                f"🌱 Total water injected: {self.total_water_injected} liters"
            )
            if self.dashboard_callback:
                self.dashboard_callback(water_injected)
        else:
            self.result_box.setText(
                f"⚠️ Water NOT injected — mineral levels insufficient for {crop} ({stage})\n"
                f"Nitrate: {nitrate} ppm, Phosphate: {phosphate} ppm, Potassium: {potassium} ppm"
            )
