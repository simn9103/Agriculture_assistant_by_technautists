# app/screens/soil_analysis.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QGroupBox, QFormLayout,
    QSpinBox, QDoubleSpinBox, QPushButton, QTextEdit
)
from PyQt5.QtCore import Qt


class SoilAnalysisScreen(QWidget):
    def __init__(self):
        super().__init__()

        self.sludge_added = 0  # Track sludge fertilizer from Biogas

        # Main layout
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🌱 Real-Time Soil Analysis")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Input section
        input_group = QGroupBox("Enter Sensor Data (Demo Inputs)")
        form_layout = QFormLayout()

        self.moisture_input = QSpinBox()
        self.moisture_input.setRange(0, 100)
        self.moisture_input.setValue(45)

        self.ph_input = QDoubleSpinBox()
        self.ph_input.setRange(0.0, 14.0)
        self.ph_input.setSingleStep(0.1)
        self.ph_input.setDecimals(2)
        self.ph_input.setValue(6.5)

        self.temp_input = QSpinBox()
        self.temp_input.setRange(-10, 60)
        self.temp_input.setValue(25)

        self.minerals_input = QSpinBox()
        self.minerals_input.setRange(0, 1000)
        self.minerals_input.setValue(70)

        # Add inputs to form layout
        form_layout.addRow("Soil Moisture (%)", self.moisture_input)
        form_layout.addRow("Soil pH", self.ph_input)
        form_layout.addRow("Temperature (°C)", self.temp_input)
        form_layout.addRow("Mineral Content (ppm)", self.minerals_input)

        input_group.setLayout(form_layout)
        layout.addWidget(input_group)

        # Analyze button
        self.analyze_btn = QPushButton("Analyze Soil")
        self.analyze_btn.clicked.connect(self.analyze_soil)
        layout.addWidget(self.analyze_btn)

        # Result display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        self.result_box.setStyleSheet("font-size:13px;")
        layout.addWidget(self.result_box)

        self.setLayout(layout)

    def add_sludge(self, amount):
        """Add sludge from Biogas Plant automatically."""
        self.sludge_added += amount
        self.analyze_soil()  # Re-analyze soil automatically when sludge is added

    def analyze_soil(self):
        """Analyze soil and provide recommendations, including sludge fertilizer."""
        moisture = self.moisture_input.value()
        ph = self.ph_input.value()
        temp = self.temp_input.value()
        minerals = self.minerals_input.value()

        recommendations = []

        # Moisture rules
        if moisture < 30:
            recommendations.append("💧 Soil moisture is low — irrigate the field.")
        elif moisture > 80:
            recommendations.append("⚠️ Soil is too wet — reduce irrigation.")

        # pH rules
        if ph < 5.5:
            recommendations.append("🧪 Soil is acidic — apply lime to neutralize.")
        elif ph > 7.5:
            recommendations.append("🧪 Soil is alkaline — add sulfur or organic matter.")

        # Minerals rules
        if minerals < 50:
            recommendations.append("🌾 Soil nutrients are low — apply NPK fertilizer.")
        elif minerals > 200:
            recommendations.append("⚠️ High mineral concentration — risk of salinity.")

        # Temperature rules
        if temp < 15:
            recommendations.append("🌡️ Soil is cold — slow germination expected.")
        elif temp > 35:
            recommendations.append("🌡️ Soil is too hot — mulch recommended.")

        # Sludge fertilizer recommendation
        if self.sludge_added > 0:
            recommendations.append(f"🌱 Sludge fertilizer added from Biogas Plant: {self.sludge_added} kg")

        # If no issues
        if not recommendations:
            recommendations.append("✅ Soil conditions are optimal for crop growth.")

        # Display recommendations
        self.result_box.setText("\n".join(recommendations))
