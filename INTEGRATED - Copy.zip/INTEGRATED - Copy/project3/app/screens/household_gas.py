# app/screens/household_gas.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QSpinBox, QPushButton, QTextEdit, QGroupBox, QComboBox
)
from PyQt5.QtCore import Qt, QTimer
import random  # simulate ambient conditions

class HouseholdGasScreen(QWidget):
    def __init__(self, soil_screen=None, lighting_screen=None, dashboard_callback=None):
        """
        soil_screen: SoilAnalysisScreen instance for soil data
        lighting_screen: LightingScreen instance to check light intensity
        dashboard_callback: optional function to log gas injection
        """
        super().__init__()

        self.soil_screen = soil_screen
        self.lighting_screen = lighting_screen
        self.dashboard_callback = dashboard_callback

        self.total_co2 = 0
        self.total_n2 = 0

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("🏠 Household Waste to Crop Gases (Automatic Injection)")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Waste input
        waste_group = QGroupBox("Household Waste Input")
        waste_layout = QVBoxLayout()
        self.waste_input = QSpinBox()
        self.waste_input.setRange(10, 1000)
        self.waste_input.setValue(100)
        waste_layout.addWidget(QLabel("Quantity of organic waste (kg):"))
        waste_layout.addWidget(self.waste_input)
        waste_group.setLayout(waste_layout)
        layout.addWidget(waste_group)

        # Temperature input
        temp_group = QGroupBox("Processing Temperature (°C)")
        temp_layout = QVBoxLayout()
        self.temp_input = QSpinBox()
        self.temp_input.setRange(10, 50)
        self.temp_input.setValue(37)
        temp_layout.addWidget(QLabel("Temperature:"))
        temp_layout.addWidget(self.temp_input)
        temp_group.setLayout(temp_layout)
        layout.addWidget(temp_group)

        # Result display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        layout.addWidget(self.result_box)

        self.setLayout(layout)

        # Timer to simulate automatic injection every 3 seconds
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_inject)
        self.timer.start(3000)

    def auto_inject(self):
        """Automatic gas injection based on crop and soil conditions."""

        # Simulate ambient light
        light_intensity = self.lighting_screen.brightness_slider.value() if self.lighting_screen else 70
        crop = "Rice"  # For demo, can be connected to Dashboard selected crop
        growth_stage = random.choice(["Vegetative", "Flowering"])

        # Soil minerals (simulate if soil screen not provided)
        minerals = self.soil_screen.minerals_input.value() if self.soil_screen else 70

        # Calculate efficiency based on processing temp
        temp = self.temp_input.value()
        if 35 <= temp <= 40:
            eff = 1.0
        elif 25 <= temp < 35:
            eff = 0.7
        else:
            eff = 0.5

        # Determine gas needs
        co2_needed = 0
        n2_needed = 0
        if crop == "Rice":
            if growth_stage == "Vegetative":
                co2_needed = 5
                n2_needed = 1
            else:
                co2_needed = 10
                n2_needed = 2
        elif crop == "Wheat":
            if growth_stage == "Vegetative":
                co2_needed = 4
                n2_needed = 1
            else:
                co2_needed = 8
                n2_needed = 2

        # Adjust CO₂ injection only if light sufficient
        co2_injected = co2_needed * eff if light_intensity >= 60 else 0
        # Adjust N₂ injection only if minerals low
        n2_injected = n2_needed * eff if minerals < 100 else 0

        self.total_co2 += co2_injected
        self.total_n2 += n2_injected

        result = (
            f"🌱 Crop: {crop} | Stage: {growth_stage}\n"
            f"💡 Light Intensity: {light_intensity}% | Soil Minerals: {minerals} ppm\n\n"
            f"💨 CO₂ Injected: {co2_injected:.2f} m³ (Total: {self.total_co2:.2f} m³)\n"
            f"💨 N₂ Injected: {n2_injected:.2f} m³ (Total: {self.total_n2:.2f} m³)\n"
        )

        self.result_box.setText(result)

        # Optionally log to Dashboard
        if self.dashboard_callback:
            self.dashboard_callback(co2_injected, n2_injected)
