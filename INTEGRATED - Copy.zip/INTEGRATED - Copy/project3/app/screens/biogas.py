# app/screens/biogas.py
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QSpinBox, QPushButton, QTextEdit, QGroupBox
)
from PyQt5.QtCore import Qt

class BiogasScreen(QWidget):
    def __init__(self, soil_analysis_callback=None):
        """
        soil_analysis_callback: optional function to send sludge info to Soil Analysis
        """
        super().__init__()

        self.soil_analysis_callback = soil_analysis_callback

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignTop)

        title = QLabel("♻️ Biogas Plant Simulation")
        title.setStyleSheet("font-size:16px; font-weight:600;")
        layout.addWidget(title)

        # Feedstock selection (only Crop Residue & Animal Manure)
        feed_group = QGroupBox("Feedstock")
        feed_layout = QVBoxLayout()
        self.feed_select = QComboBox()
        self.feed_select.addItems(["Crop Residue", "Animal Manure"])
        feed_layout.addWidget(QLabel("Select Feedstock Type:"))
        feed_layout.addWidget(self.feed_select)
        feed_group.setLayout(feed_layout)
        layout.addWidget(feed_group)

        # Quantity input
        qty_group = QGroupBox("Quantity")
        qty_layout = QVBoxLayout()
        self.qty_input = QSpinBox()
        self.qty_input.setRange(10, 1000)
        self.qty_input.setValue(100)
        qty_layout.addWidget(QLabel("Feedstock Quantity (kg):"))
        qty_layout.addWidget(self.qty_input)
        qty_group.setLayout(qty_layout)
        layout.addWidget(qty_group)

        # Temperature input
        temp_group = QGroupBox("Temperature (°C)")
        temp_layout = QVBoxLayout()
        self.temp_input = QSpinBox()
        self.temp_input.setRange(10, 50)
        self.temp_input.setValue(37)
        temp_layout.addWidget(QLabel("Digester Temperature:"))
        temp_layout.addWidget(self.temp_input)
        temp_group.setLayout(temp_layout)
        layout.addWidget(temp_group)

        # Generate button
        self.gen_btn = QPushButton("Simulate Biogas Production")
        self.gen_btn.clicked.connect(self.simulate_biogas)
        layout.addWidget(self.gen_btn)

        # Result display
        self.result_box = QTextEdit()
        self.result_box.setReadOnly(True)
        layout.addWidget(self.result_box)

        self.setLayout(layout)

    def simulate_biogas(self):
        feed = self.feed_select.currentText()
        qty = self.qty_input.value()
        temp = self.temp_input.value()

        # Base yield and sludge
        yields = {"Crop Residue": (25, 50), "Animal Manure": (30, 60)}  # (biogas m³/100kg, sludge kg/100kg)
        base_gas, base_sludge = yields[feed]

        # Efficiency factor based on temperature
        if 35 <= temp <= 40:
            eff = 1.0
        elif 25 <= temp < 35:
            eff = 0.7
        else:
            eff = 0.5

        gas = round((qty / 100) * base_gas * eff, 2)
        sludge = round((qty / 100) * base_sludge * eff, 2)

        result = (
            f"🔹 Feedstock: {feed}\n"
            f"🔹 Quantity: {qty} kg\n"
            f"🔹 Digester Temp: {temp}°C\n\n"
            f"💨 Biogas Produced: {gas} m³\n"
            f"🌱 Sludge Produced: {sludge} kg (can be used as fertilizer)\n"
        )

        self.result_box.setText(result)

        # Automatically send sludge info to Soil Analysis (if callback provided)
        if self.soil_analysis_callback:
            self.soil_analysis_callback(sludge)
