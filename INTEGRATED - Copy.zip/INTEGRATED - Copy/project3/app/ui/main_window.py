from PyQt5.QtWidgets import QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLabel
from app.screens.dashboard import DashboardScreen
from app.screens.soil_analysis import SoilAnalysisScreen
from app.screens.weather import WeatherScreen
from app.screens.pest_detection import PestDetectionScreen
from app.screens.irrigation import IrrigationScreen  
from app.screens.alerts import AlertsScreen
from app.screens.lighting import LightingScreen
from app.screens.biogas import BiogasScreen  
from app.screens.household_gas import HouseholdGasScreen
from app.screens.aquaponics import AquaponicsScreen

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🌱 Smart Agricultural Assistant")
        self.setGeometry(200, 100, 1000, 600)

        # Tab widget
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        # Create SoilAnalysisScreen first (needed for Biogas callback)
        self.soil_screen = SoilAnalysisScreen()

        # Add actual screens
        self.tabs.addTab(DashboardScreen(), "Dashboard")
        self.tabs.addTab(self.soil_screen, "Soil Analysis")  # Use instance
        self.tabs.addTab(WeatherScreen(), "Weather")
        self.tabs.addTab(PestDetectionScreen(), "Pest Detection")
        self.tabs.addTab(IrrigationScreen(), "Irrigation") 
        self.tabs.addTab(AlertsScreen(), "Alerts")
        self.tabs.addTab(LightingScreen(), "Artificial Lighting")
        self.tabs.addTab(HouseholdGasScreen(), "Household Gas")
        self.tabs.addTab(AquaponicsScreen(), "Aquaponics")

        # Add Biogas Plant with callback to Soil Analysis
        self.tabs.addTab(BiogasScreen(soil_analysis_callback=self.soil_screen.add_sludge), "Biogas Plant")

    def add_tab(self, name, text):
        """Helper function to add a placeholder tab"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel(text))
        tab.setLayout(layout)
        self.tabs.addTab(tab, name)
